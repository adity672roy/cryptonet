import React, { useState, useEffect } from "react";

const App = () => {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    fetch("https://randomuser.me/api/?page=1&results=1&seed=abc")
      .then((response) => response.json())
      .then((data) => {
        const user = data.results[0];

        setUserData(user);
        console.log(user);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);
  return (
    <div>
      {userData ? (
        <div className="flex flex-col m-4 items-center   bg-white   border border-gray-200  rounded-lg shadow md:flex-row md:max-w-xl hover:bg-gray-100 dark:border-gray-700 dark:bg-gray-800 dark:hover:bg-gray-700 font-mono">
          <img
            className="object-cover w-100 h-100 m-1   md:h-auto md:w-48  border border-gray-400 rounded-lg shadow"
            src={userData.picture.large}
            alt={userData.name.first}
          />
          <div className="flex flex-col justify-between p-4 leading-normal">
            <p className="mb-1 font-normal text-gray-700 dark:text-gray-400 capitalize">
              <span className="font-bold">Name : </span>
              {userData.name.title} {userData.name.first} {userData.name.last}
            </p>
            <p className="  mb-1 font-normal text-gray-700 dark:text-gray-400 capitalize">
              <span className="font-bold">Age : </span>
              {userData.dob.age}
            </p>
            <p className="mb-1 font-normal text-gray-700 dark:text-gray-400 capitalize">
              <span className="font-bold">Gender : </span>
              {userData.gender}
            </p>
            <p className="mb-1 font-normal text-gray-700 dark:text-gray-400">
              <span className="font-bold">Email : </span>
              {userData.email}
            </p>
            <p className="mb-1 font-normal text-gray-700 dark:text-gray-400">
              <span className="font-bold">Phone : </span>
              {userData.phone} , {userData.cell}
            </p>
            <p className="mb-1 font-normal text-gray-700 dark:text-gray-400">
              <span className="font-bold">Location : </span>
              {userData.location.street.number} {userData.location.street.name},{" "}
              {userData.location.city}, {userData.location.country},
              {userData.location.postcode}
            </p>
          </div>
        </div>
      ) : (
        <div class="text-center">
          <span>Loading...</span>
        </div>
      )}
    </div>
  );
};

export default App;
